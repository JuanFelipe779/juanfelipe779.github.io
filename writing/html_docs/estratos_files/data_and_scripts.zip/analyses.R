library(rethinking)
library(ggdist)
library(kableExtra)
#set cmdstan path, configured preciously with the Ctools chain
#set_cmdstan_path("C:\\Program Files\\R\\cmdstan\\cmdstan") 

#### data ####
# data lists to pass to ulam
final_df_no_2007 <- final_df|> 
  filter(years != 2007) |> 
  select(c(1:5))

final_df_2013_onwards <- final_df|> 
  filter(years > 2012) |> 
  select(c(1:5))

d_2008_onwards <- list(
  #solicitudes = final_df_no_2007$solicitudes,
  success = final_df_no_2007$beneficiarixs,
  pre_success = final_df_no_2007$aprobadas,
  estrato = final_df_no_2007$estrato,
  year = as.numeric(as.factor(final_df_no_2007$years))
)

d_2013_onwards <- list(
  solicitudes = final_df_2013_onwards$solicitudes,
  success = final_df_2013_onwards$beneficiarixs,
  pre_success = final_df_2013_onwards$aprobadas,
  estrato = final_df_2013_onwards$estrato,
  year = as.numeric(as.factor(final_df_2013_onwards$years))
)

#### pre-success conditional on applying ####
model_pre_success_vs <- ulam(
  alist(
    pre_success ~ dbinom(solicitudes, p),
    
    logit(p) <- a_bar + z[estrato]*sigma_z_estrato + v[estrato,year],
    
    transpars> matrix[estrato,12]:v <- compose_noncentered(sigma_estrato, L_Rho_estrato, z_estrato),
    
    a_bar ~ dnorm(0,0.5),
    sigma_z_estrato ~ dexp(1),
    z[estrato] ~ dnorm(0,1),
    
    matrix[12,estrato]:z_estrato ~ normal(0,1), # Inverted matrix, 12 rows and 6 columns
    vector[12]: sigma_estrato ~ dexp(1),
    cholesky_factor_corr[12]:L_Rho_estrato ~ lkj_corr_cholesky(2),
    
    gq>matrix[12,12]:Rho_estrato <<- Chol_to_Corr(L_Rho_estrato),
    gq>vector[estrato]:a_estrato <<- a_bar + z*sigma_z_estrato
    
    
  ), data = d_2013_onwards, chains = 4, cores = 8, iter = 4000, log_lik = T
)

# Check model; some Pareto values are high
model_success_pareto <- PSIS(model_pre_success_vs, pointwise= T)
model_success_waic <- WAIC(model_pre_success_vs, pointwise = T)
plot(model_success_pareto$k, model_success_waic$penalty)

# Check fixed effects of estrato
precis(model_pre_success_vs, depth = 2, pars = "a_estrato")
plot(precis(model_pre_success_vs, depth = 2, pars = "a_estrato"))

# from log-odds to probability scale
post_model_pre_success_vs <- extract.samples(model_pre_success_vs)
marginal_probs_pre_success_vs <- data.frame(
  est_1 = inv_logit(post_model_pre_success_vs$a_estrato[,1]),
  est_2 = inv_logit(post_model_pre_success_vs$a_estrato[,2]),
  est_3 = inv_logit(post_model_pre_success_vs$a_estrato[,3]),
  est_4 = inv_logit(post_model_pre_success_vs$a_estrato[,4]),
  est_5 = inv_logit(post_model_pre_success_vs$a_estrato[,5]),
  est_6 = inv_logit(post_model_pre_success_vs$a_estrato[,6])
)

# see estimates
precis(marginal_probs_pre_success_vs)
plot(precis(marginal_probs_pre_success_vs))

# contrast between estrato 1 and 6
diff_estrato_1_to_6_pre_success_vs <- inv_logit(post_model_pre_success_vs$fixed_estrato[,1]) - inv_logit(post_model_pre_success_vs$fixed_estrato[,6])
precis(diff_estrato_1_to_6_pre_success_vs)

# Change column ([,,1 to 10]) to check how the proabability is estimated according to each year (1 = 2013, ..., 10 = 2024)
marginal_probs_pre_success_per_year <- data.frame(
  est_1 = inv_logit(post_model_pre_success_vs$alpha[1:8000,1,4]),
  est_2 = inv_logit(post_model_pre_success_vs$alpha[1:8000,2,4]),
  est_3 = inv_logit(post_model_pre_success_vs$alpha[1:8000,3,4]),
  est_4 = inv_logit(post_model_pre_success_vs$alpha[1:8000,4,4]),
  est_5 = inv_logit(post_model_pre_success_vs$alpha[1:8000,5,4]),
  est_6 = inv_logit(post_model_pre_success_vs$alpha[1:8000,6,4])
)
precis(marginal_probs_pre_success_per_year)
plot(precis(marginal_probs_pre_success_per_year))

# Log-odds table
log_odds_kable <- as.data.frame(precis(model_pre_success_vs, depth = 2, pars = "a_estrato"))
log_odds_kable <- log_odds_kable[,c(-6)]
log_odds_kable <- round(log_odds_kable,2)
names(log_odds_kable) <- c("M","DE","IC 5.5%","IC 94.5","Rhat")
rownames(log_odds_kable) <- c("Estrato 1","Estrato 2","Estrato 3",
                              "Estrato 4","Estrato 5","Estrato 6")
log_odds_kable |> 
  kbl(align = "c") |> 
  kable_classic(full_width = T) |> 
  footnote(
    general = "M = Media. DE = Desviación estandar. IC = Intervalo de compatibilidad. Los parametros están enescala de log-odds"
  )

# parameters slab
slab_model_pre_success <- data.frame(post_model_pre_success_vs$a_estrato[,1], post_model_pre_success_vs$a_estrato[,2],
                                     post_model_pre_success_vs$a_estrato[,3], post_model_pre_success_vs$a_estrato[,4],
                                     post_model_pre_success_vs$a_estrato[,5], post_model_pre_success_vs$a_estrato[,6])
names(slab_model_pre_success) <- c("Estrato 1","Estrato 2","Estrato 3",
                                   "Estrato 4", "Estrato 5","Estrato 6")
slab_model_pre_success <- slab_model_pre_success %>%
  pivot_longer(
    cols = c(1:6),
    names_to = "variable",
    values_to = "value"
  )

ggplot(slab_model_pre_success, aes(value, variable)) + 
  stat_halfeye(
    slab_alpha = .48,
    slab_fill = "azure4",
    interval_size_range = c(0.8,1.6)
  ) + 
  geom_vline(xintercept = 0, linetype = "dashed") + 
  theme_minimal(base_size = 12)  +
  xlab("log-odds") + 
  ylab("Estimado")

# slab probability
slab_model_pre_success <- data.frame(inv_logit(post_model_pre_success_vs$a_estrato[,1]), inv_logit(post_model_pre_success_vs$a_estrato[,2]),
                                     inv_logit(post_model_pre_success_vs$a_estrato[,3]), inv_logit(post_model_pre_success_vs$a_estrato[,4]),
                                     inv_logit(post_model_pre_success_vs$a_estrato[,5]), inv_logit(post_model_pre_success_vs$a_estrato[,6]))
names(slab_model_pre_success) <- c("Estrato 1","Estrato 2","Estrato 3",
                                   "Estrato 4", "Estrato 5","Estrato 6")
slab_model_pre_success <- slab_model_pre_success %>%
  pivot_longer(
    cols = c(1:6),
    names_to = "variable",
    values_to = "value"
  )

ggplot(slab_model_pre_success, aes(value, variable)) + 
  stat_halfeye(
    slab_alpha = .48,
    slab_fill = "azure4",
    interval_size_range = c(0.8,1.6)
  ) + 
  geom_vline(xintercept = 0.5, linetype = "dashed") + 
  theme_minimal(base_size = 12)  +
  xlab("Probabilidad") + 
  ylab("Estimado")

# contrasts
diffs <- list(
  "Estrato 1 x Estrato 6" = inv_logit(post_model_pre_success_vs$a_estrato[,1]) - inv_logit(post_model_pre_success_vs$a_estrato[,6]),
  "Estrato 2 x Estrato 5" = inv_logit(post_model_pre_success_vs$a_estrato[,2]) - inv_logit(post_model_pre_success_vs$a_estrato[,5]),
  "Estrato 3 x Estrato 4" = inv_logit(post_model_pre_success_vs$a_estrato[,3]) - inv_logit(post_model_pre_success_vs$a_estrato[,4])
)

diffs_kable <- as.data.frame(precis(diffs))
diffs_kable <- diffs_kable[,c(-5)]
diffs_kable <- round(diffs_kable,2)
names(diffs_kable) <- c("M","DE","IC 5.5%","IC 94.5")
rownames(diffs_kable) <- c("Estrato 1 - Estrato 6","Estrato 2 - Estrato 5","Estrato 3 - Estrato 6")
diffs_kable |> 
  kbl(align = "c") |> 
  kable_classic(full_width = T) |> 
  footnote(
    general = "M = Media. DE = Desviación estandar. IC = Intervalo de compatibilidad. Los parametros están enescala de probabilidad"
  )

# slabs contrasts
slab_diffs <- data.frame(diffs)
names(slab_diffs) <- c("Estrato 1 - Estrato 6","Estrato 2 - Estrato 5","Estrato 3 - Estrato 6")
slab_diffs <- slab_diffs %>%
  pivot_longer(
    cols = c(1:3),
    names_to = "variable",
    values_to = "value"
  )

ggplot(slab_diffs, aes(value, variable)) + 
  stat_halfeye(
    slab_alpha = .48,
    slab_fill = "azure4",
    interval_size_range = c(0.8,1.6)
  ) + 
  geom_vline(xintercept = 0, linetype = "dashed") + 
  theme_minimal(base_size = 12)  +
  xlab("Probabilidad") + 
  ylab("Contraste")

# variation per year
p_post <- as.data.frame(p_post)
p_post_long <- p_post |> 
  pivot_longer(
    cols=c(1:72),
    values_to = "values",
    names_to = "id"
  ) |> 
  add_column(
    estrato_id = rep(1:6,times=8000, length.out=576000),
    year = rep(2013:2024,each=6,length.out=576000),
    year_id = rep(1:72,times=8000,length.out=576000)
  ) |> 
  mutate(
    estrato=as.factor(estrato_id),
    year=as.factor(year),
    year_id=as.factor(year_id)
  )

ggplot(p_post_long, aes(values,year_id,colour=estrato)) + 
  stat_pointinterval() + 
  geom_vline(xintercept = 0.5, linetype="dashed") +
  scale_color_brewer(palette="Set2") + 
  xlab("Probabilidad") + 
  ylab("Periodo") +
  theme_minimal()

#### success conditional on application being accepted ####
model_success_vs <- ulam(
  alist(
    success ~ dbinom(pre_success, p),
    
    logit(p) <- a_bar + z[estrato]*sigma_z_estrato + v[estrato,year],
    
    transpars> matrix[estrato,17]:v <- compose_noncentered(sigma_estrato, L_Rho_estrato, z_estrato),
    
    a_bar ~ dnorm(0,0.5),
    sigma_z_estrato ~ dexp(1),
    z[estrato] ~ dnorm(0,1),
    
    matrix[17,estrato]:z_estrato ~ normal(0,1), # Inverted matrix, 12 rows and 6 columns
    vector[17]: sigma_estrato ~ dexp(1),
    cholesky_factor_corr[17]:L_Rho_estrato ~ lkj_corr_cholesky(2),
    
    gq>matrix[17,17]:Rho_estrato <<- Chol_to_Corr(L_Rho_estrato),
    gq>vector[estrato]:a_estrato <<- a_bar + z*sigma_z_estrato
    
  ), data = d_2008_onwards, chains = 4, cores = 8, iter = 4000, log_lik = T
)

# High Pareto values; understandable since there is not so much data.
model_success_pareto <- PSIS(model_success_vs, pointwise= T)
model_success_waic <- WAIC(model_success_vs, pointwise = T)
plot(model_success_pareto$k, model_success_waic$penalty)

# See fixed effects of estrato, i.e., marginal means
precis(model_success_vs, depth = 2, pars = "a_estrato")
plot(precis(model_success_vs, depth = 2, pars = "a_estrato"))

# Varying effects per year
# precis(model_success_vs, depth = 3, pars = "alpha")
# plot(precis(model_success_vs, depth = 3, pars = "alpha"))

# From log-odds to probability
post_success_vs <- extract.samples(model_success_vs)
marginal_probs <- data.frame(
  est_1 = inv_logit(post_success_vs$a_estrato[,1]),
  est_2 = inv_logit(post_success_vs$a_estrato[,2]),
  est_3 = inv_logit(post_success_vs$a_estrato[,3]),
  est_4 = inv_logit(post_success_vs$a_estrato[,4]),
  est_5 = inv_logit(post_success_vs$a_estrato[,5]),
  est_6 = inv_logit(post_success_vs$a_estrato[,6])
)

# See marginal estimates in probability scale
precis(marginal_probs)
plot(precis(marginal_probs))

marginal_probs_kable <- as.data.frame(precis(marginal_probs, depth = 2, pars = "a_estrato"))
marginal_probs_kable <- marginal_probs_kable[,c(-5)]
marginal_probs_kable <- round(marginal_probs_kable,2)
names(marginal_probs_kable) <- c("M","DE","IC 5.5%","IC 94.5")
rownames(marginal_probs_kable) <- c("Estrato 1","Estrato 2","Estrato 3",
                                    "Estrato 4","Estrato 5","Estrato 6")
marginal_probs_kable |> 
  kbl() |> 
  kable_classic(full_width = F)

# contrast between estrato 1 and 6
diff_estrato_1_to_6 <- inv_logit(post_success_vs$fixed_estrato[,1]) - inv_logit(post_success_vs$fixed_estrato[,6])
precis(diff_estrato_1_to_6)

# Change column ([,,1 to 10]) to check how the proabability is estimated according to each year (1 = 2013, ..., 10 = 2024)
marginal_probs_per_year <- data.frame(
  est_1 = inv_logit(post_success_vs$alpha[1:8000,1,2]),
  est_2 = inv_logit(post_success_vs$alpha[1:8000,2,2]),
  est_3 = inv_logit(post_success_vs$alpha[1:8000,3,2]),
  est_4 = inv_logit(post_success_vs$alpha[1:8000,4,2]),
  est_5 = inv_logit(post_success_vs$alpha[1:8000,5,2]),
  est_6 = inv_logit(post_success_vs$alpha[1:8000,6,2])
)
precis(marginal_probs_per_year)
plot(precis(marginal_probs_per_year))

slab_model_success <- data.frame(inv_logit(post_success_vs$a_estrato[,1]), inv_logit(post_success_vs$a_estrato[,2]),
                                 inv_logit(post_success_vs$a_estrato[,3]), inv_logit(post_success_vs$a_estrato[,4]),
                                 inv_logit(post_success_vs$a_estrato[,5]), inv_logit(post_success_vs$a_estrato[,6]))
names(slab_model_success) <- c("Estrato 1","Estrato 2","Estrato 3",
                                   "Estrato 4", "Estrato 5","Estrato 6")
slab_model_success <- slab_model_success %>%
  pivot_longer(
    cols = c(1:6),
    names_to = "variable",
    values_to = "value"
  )

ggplot(slab_model_success, aes(value, variable)) + 
  stat_halfeye(
    slab_alpha = .48,
    slab_fill = "azure4",
    interval_size_range = c(0.8,1.6)
  ) + 
  geom_vline(xintercept = 0.5, linetype = "dashed") + 
  theme_minimal(base_size = 12)  +
  xlab("Probabilidad") + 
  ylab("Estimado")

# table log-odds
log_odds_kable <- as.data.frame(precis(model_success_vs, depth = 2, pars = "a_estrato"))
log_odds_kable <- log_odds_kable[,c(-6)]
log_odds_kable <- round(log_odds_kable,2)
names(log_odds_kable) <- c("M","DE","IC 5.5%","IC 94.5","Rhat")
rownames(log_odds_kable) <- c("Estrato 1","Estrato 2","Estrato 3",
                              "Estrato 4","Estrato 5","Estrato 6")
log_odds_kable |> 
  kbl(align = "c") |> 
  kable_classic(full_width = T) |> 
  footnote(
    general = "M = Media. DE = Desviación estandar. IC = Intervalo de compatibilidad. Los parametros están enescala de log-odds"
  )

# Contrasts
diffs <- list(
  "Estrato 1 x Estrato 6" = inv_logit(post_success_vs$a_estrato[,1]) - inv_logit(post_success_vs$a_estrato[,6]),
  "Estrato 2 x Estrato 5" = inv_logit(post_success_vs$a_estrato[,2]) - inv_logit(post_success_vs$a_estrato[,5]),
  "Estrato 3 x Estrato 4" = inv_logit(post_success_vs$a_estrato[,3]) - inv_logit(post_success_vs$a_estrato[,4])
)

diffs_kable <- as.data.frame(precis(diffs))
diffs_kable <- diffs_kable[,c(-5)]
diffs_kable <- round(diffs_kable,2)
names(diffs_kable) <- c("M","DE","IC 5.5%","IC 94.5")
rownames(diffs_kable) <- c("Estrato 1 - Estrato 6","Estrato 2 - Estrato 5","Estrato 3 - Estrato 4")
diffs_kable |> 
  kbl(align = "c") |> 
  kable_classic(full_width = T) |> 
  footnote(
    general = "M = Media. DE = Desviación estandar. IC = Intervalo de compatibilidad. Los parametros están enescala de probabilidad"
  )

# slabs contrasts
slab_diffs <- data.frame(diffs)
names(slab_diffs) <- c("Estrato 1 - Estrato 6","Estrato 2 - Estrato 5","Estrato 3 - Estrato 4")
slab_diffs <- slab_diffs %>%
  pivot_longer(
    cols = c(1:3),
    names_to = "variable",
    values_to = "value"
  )

ggplot(slab_diffs, aes(value, variable)) + 
  stat_halfeye(
    slab_alpha = .48,
    slab_fill = "azure4",
    interval_size_range = c(0.8,1.6)
  ) + 
  geom_vline(xintercept = 0, linetype = "dashed") + 
  theme_minimal(base_size = 12)  +
  xlab("Probabilidad") + 
  ylab("Contraste")

# variation per year
datp <- list(
  estrato = rep(1:6, each = 17),
  year = rep(1:17, times = 6)
)
p_post <- link(model_success_vs, datp)
p_post <- as.data.frame(p_post)
p_post_long <- p_post |> 
  pivot_longer(
    cols=c(1:102),
    values_to = "values",
    names_to = "id"
  ) |> 
  add_column(
    estrato_id = rep(1:6,times=8000, length.out=816000),
    year = rep(2013:2024,each=6,length.out=816000),
    year_id = rep(1:102,times=8000,length.out=816000)
  ) |> 
  mutate(
    estrato=as.factor(estrato_id),
    year=as.factor(year),
    year_id=as.factor(year_id)
  )

ggplot(p_post_long, aes(values,year_id,colour=estrato)) + 
  stat_pointinterval() + 
  geom_vline(xintercept = 0.5, linetype="dashed") +
  scale_color_brewer(palette="Set2") + 
  xlab("Probabilidad") + 
  ylab("Periodo") +
  theme_minimal()



####print###








